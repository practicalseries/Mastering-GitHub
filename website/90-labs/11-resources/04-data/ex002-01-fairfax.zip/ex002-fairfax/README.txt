MASTERING GITHUB — EXAMPLE 002                               ex002-01-fairfax.zip


MODIFICATION HISTORY

____________________________________________________________________________________________________________________
REVISION              MAIN - COMMIT 001
File                  Path                         Size      Details                                         Change
--------------------------------------------------------------------------------------------------------------------
README.txt            root                          3KB      This file (created)                             ADD
 
index.html            root                          5KB      Main HTML file for example page                 ADD
                                                             First release (file created)
--------------------------------------------------------------------------------------------------------------------
style.css             \11-resources\01-css          2KB      Main CSS file for example page                  ADD
                                                             First release (file created)
--------------------------------------------------------------------------------------------------------------------
favicon.svg           \11-resources\02-images       7KB      Favicon image
fig-01-01.png         \11-resources\02-images      43KB      Page image (site map)                           ADD
fig-01-02.png         \11-resources\02-images      56KB      Page image (plant schematic) not yet used       ADD
logo-mgh.svg          \11-resources\02-images      20KB      Mastering GitHub logo                           ADD
logo-wtw.svg          \11-resources\02-images      46KB      Fairfax WTW logo                                ADD
———————————————————————————————————————————————————————————————————————————————————————————————————————————————————

Change	ADD  File added
        DEL  File deleted
        MOD  File modified 